# Lean declaration scan

This is a repository-side declaration scan of the exact extracted Aristotle
return. It is not an independent replay of `lake build`.

## Pinned toolchain

```text
leanprover/lean4:v4.28.0
```

The returned `lakefile.toml` pins:

```text
rev = "v4.28.0"
```

## Foundational files

Command:

```bash
grep -nE '(^|[^[:alnum:]_])(sorry|admit|unsafe)([^[:alnum:]_]|$)|^[[:space:]]*(axiom|constant)([[:space:]]|$)' \
  formalization/aristotle_return_v1/RequestProject/POVM.lean \
  formalization/aristotle_return_v1/RequestProject/Main.lean
```

Output: none. Exit status: `1`, meaning no match.

## Exact-scope statements

The scan for `admit`, `unsafe`, new `axiom`, or new `constant` in
`Statements.lean` also returned no matches with exit status `1`.

The exact `sorry` scan returned:

```text
63:  sorry
126:  sorry
157:  sorry
```

The associated declarations are:

```text
54:theorem thm_main
110:theorem cor_tuple
142:theorem cor_square
```

Therefore the returned project contains exactly three disclosed headline
proof gaps. It does not formally verify the manuscript theorem or its two
operator corollaries.

## Archive

```text
1887d86be11c597cfcbc604346b3efb55260cb3bbecbf69720443c5210b6bc1f  6f13344c-d5b5-4805-ab3d-e779ff868afb-aristotle.tar.gz
```
