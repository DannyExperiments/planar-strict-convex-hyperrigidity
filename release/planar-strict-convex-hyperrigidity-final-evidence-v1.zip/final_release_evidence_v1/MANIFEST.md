# Self-contained final release evidence bundle

This directory supplies the exact bytes omitted from the two-file submission
criticized in `audits/final_release_hostile_referee_report.md`.

It is an evidence and reproducibility package, not a mathematical proof and
not human peer review. The ordinary mathematical proof is the TeX file under
`paper/`; the final release audit passed every numbered theorem, lemma, and
corollary statement but returned `OVERALL REPAIRABLE` for documentary reasons.

## Contents

- `paper/`: the post-audit documentary wording revision of the manuscript.
- `sources/`: the two frozen ordinary-proof source artifacts.
- `audits/`: all eight complete AI-generated audit returns, including the
  final documentary re-audit report.
- `literature/`: the two final solution-aware prior-art reports.
- `formalization/`: the exact Aristotle archive, extracted returned project,
  submission/status records, and gap report.
- `declarations/`: the reproducible Lean declaration scan and its exact
  output.
- `build/`: the fresh CI job log, artifact ZIP, compiled PDF, and build record.
  It also contains the exact workflow and build/verification scripts.
- `metadata/`: disclosure, claims, provenance, publication status, and the
  immutable-source manifest.
- `audit_inputs/`: the first final-release prompt and evidence packet, retained
  so that the referee's criticism is reproducible.
- `DOCUMENTARY_REPAIRS.md`: the exact nonmathematical corrections made in
  response to the final report.
- `ROOT_SHA256SUMS`: SHA-256 for every file in this directory except that
  checksum file itself.

## Verification

From this directory run:

```bash
shasum -a 256 -c ROOT_SHA256SUMS
```

The repository-level verification script remains authoritative for the
repository structure. The Aristotle return is not a proof of the headline
theorem: `thm_main`, `cor_tuple`, and `cor_square` remain explicit `sorry`
declarations, exactly as recorded here.

The exact post-audit source commit, CI run, job, artifact, PDF properties,
hashes, and visual-inspection result are recorded in
`build/BUILD_RECORD.md`.
